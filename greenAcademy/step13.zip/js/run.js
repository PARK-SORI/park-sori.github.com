$(function(){
	$('.keb-gnb>ul>li>a').on('mouseover',function(){
		$('.bar').height(24);

	});
	$('.keb-gnb>ul').on('mouseleave',function(){
		$('.bar').height(0);
		$('.keb-gnb>ul>li>ul').hide();
	});
});