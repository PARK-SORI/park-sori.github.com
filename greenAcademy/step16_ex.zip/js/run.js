$(function(){
	$('.bx-img').bxSlider({
		pager:false,//pagination안보이기
		minSlides:4,//최소몇개의 슬라이더(사진)이 보일거냐
		maxSlides:4,
		slideMargin:0,
		slideWidth:250,
		moveSlides:1,//움직이는 슬라이더(사진)의 개수 1개,이걸 안 넣으면 4개씩 움직임
	});
});

//일반jquery.min.js로 만들경우
$(function(){
  $('.prev').on('click',function(){
    $('.img-container').animate({
      left:0
    },function(){
      $('.img-container img:last').prependTo($('.img-container'))
      $('.img-container').css({left:-250})
    })
  });
  $('.next').on('click',function(){
    $('.img-container').animate({
      left:-500
    },function(){
      $('.img-container img:first').appendTo($('.img-container'))
      $('.img-container').css({left:-250})
    })
  });
});

//같은거지만 bxSlider가 더 빠르다.
