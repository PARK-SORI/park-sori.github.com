$(function(){
	var n=0;
	$('.tab a').on('click',function(){
		n=$('.tab a').index($(this));
		$('.list .item').eq(n).addClass('on').siblings().removeClass('on');
		$('.tab a').eq(n).addClass('on').siblings().removeClass('on');
	});
	
	$('.controls .btn_next').on('click',function(){
		if(n>2){n=0}
		else{n=n+1;};
		
		$('.list .item').eq(n).addClass('on').siblings().removeClass('on');
		$('.tab a').eq(n).addClass('on').siblings().removeClass('on');
	});
	
	$('.controls .btn_prev').on('click',function(){
		if(n<1){n=3}
		else{n=n-1;};//n이3일때0으로 돌아라가라 캐로셀형태. 처음위치는0이고 버튼을 누를때마다 넘어가야되니깐n에하나씩 더한다
		
		$('.list .item').eq(n).addClass('on').siblings().removeClass('on');
		$('.tab a').eq(n).addClass('on').siblings().removeClass('on');
	});
	
	
});
