
$(function(){
  var posY=[0,500,1100,1675,2075] //순서값은 0부터 0,1,2,3,4
  $('.gnb a').on('click',function(e){
    e.preventDefault(); //a가 있지만 다른페이지로 넘어가는게 아니기때문에 기능을 없애줌
    idx=$('.gnb a').index($(this)); //순서값은 0부터 0,1,2,3,4
    $('.gnb li').eq(idx).addClass('on').siblings().removeClass('on'); 
    //li에 클래스는 주는데 대상은 이미 정의한 idx. 그리고 클릭하지않고 스크롤만해도 색이 바뀌어야함
    $('html,body').animate({
      scrollTop:posY[idx] //순서값을 줌
    });
  });// 윈도우는태그가 아니라서 따옴표를 안씀
  $(window).scroll(function(){
  	if($(window).scrollTop()>=500 && $(window).scrollTop()<1100){
  		$('.gnb li').eq(1).addClass('on').siblings().removeClass('on');
  	}else if($(window).scrollTop()>=1100 && $(window).scrollTop()<1675){
  		$('.gnb li').eq(2).addClass('on').siblings().removeClass('on');
  	}else if($(window).scrollTop()>=1675 && $(window).scrollTop()<2075){
  		$('.gnb li').eq(3).addClass('on').siblings().removeClass('on');
  	}else if($(window).scrollTop()>=2075){
  		$('.gnb li').eq(4).addClass('on').siblings().removeClass('on');
  	}else{
  		$('.gnb li').eq(0).addClass('on').siblings().removeClass('on');
  	}
  });
});
