$(function(){
	$('.one-depth>a').click(function(e){
		e.preventDefault();
		$('.one-depth>ul:visible').slideUp().parent().removeClass('on');
		//여기에 클래스 삭제를 넣어줘야 다시 되돌아 갔을때 붉은색이 사라진다.
		$(this).next(':hidden').slideDown().parent().addClass('on').siblings().removeClass('on'); //부모인 li에 클래스 on을 추가 이때 형제들은 on을 없애줘서 단 하나의 li만 선택되게 한다.
	});
});