$(function(){
	$('.one-depth>a').on('click',function(e){
		e.preventDefault();
		$('.one-depth>ul:visible').slideUp().parent().removeClass('on');
		//여기에 클래스 삭제를 넣어줘야 다시 되돌아 갔을때 붉은색이 사라진다.
		$(this).next(':hidden').slideDown().parent().addClass('on').siblings().removeClass('on'); //this이것의.next동생이 숨겨져 있을때 슬라이드 되는데, 부모인 li에 클래스 on을 추가 이때 형제들은 on을 없애줘서 단 하나의 li만 선택되게 한다.
	}).on('focus',function(){
		$(this).click();//위에 정의된걸 다시 불러옴
		});//접근성, 초점이동시(포커스될때) 엔터를 안쳐도 자동으로 서브메뉴가 나오게
});//객체가 같은이 끊지말고 합쳐서 쓰기. 


/* 
.on도 제이썬으로 합칠수있다.

$(function(){
  $('.one-depth>a').on({
    click:function(e){
      e.preventDefault();
      $('.one-depth>ul:visible').slideUp().parent().removeClass('on'); $(this).next(':hidden').slideDown().parent().addClass('on').siblings().removeClass('on');
    },
    focus:function(){
      $(this).click();
    }
});

*/