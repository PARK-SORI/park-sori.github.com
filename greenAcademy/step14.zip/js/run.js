$(function(){
  	$('.on-depth>a').on('mouseover',function(){
	    $(this).parent().addClass('on').siblings().removeClass('on');
	    $('.on-depth ul').hide(); //여기까지가 전제 조건
	    $(this).next().show();
	  }).parent().on('mouseleave',function(){
	     $(this).find('ul').hide();
	     $(this).removeClass('on');
	  });   
  });

//한번에 합친거, 합쳤기때문에 변수를 불러오지않아도 된다.클래스 주고받는걸 먼저 기술


/*
$(function(){
	$('.on-depth>a').mouseover(function(){
		var n=$('.on-depth>a').index($(this));
		$('.on-depth ul').hide();
		$('.on-depth').eq(n).find('ul').show();
		$(this).parent().addClass('on').siblings().removeClass('on');
	})
	$('.on-depth').mouseleave(function(){
		$(this).find('ul').hide();
		$(this).parent().removeClass('on');
	})
});
*/

